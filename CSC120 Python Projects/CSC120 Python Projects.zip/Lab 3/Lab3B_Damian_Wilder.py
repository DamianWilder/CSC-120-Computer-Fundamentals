counter = 0
while counter <= 20:
    if counter % 2 == 0:
        print(counter)
    counter += 1
