number = int(input('Input a number: '))
if number % 2 == 0:
    print('The number you gave was an even number.')
else:
    print('The number you gave was an odd number.')
